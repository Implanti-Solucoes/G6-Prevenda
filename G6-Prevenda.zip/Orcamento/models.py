from django.db import models
from core.models import Uteis


# Create your models here.
class Orcamento(models.Model):
    pass