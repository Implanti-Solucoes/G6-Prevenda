from django.apps import AppConfig


class OrcamentoConfig(AppConfig):
    name = 'Orcamento'
