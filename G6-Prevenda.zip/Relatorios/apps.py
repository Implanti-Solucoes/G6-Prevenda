from django.apps import AppConfig


class RelatoriosConfig(AppConfig):
    name = 'Relatorios'
