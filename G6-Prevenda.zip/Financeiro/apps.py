from django.apps import AppConfig


class ReciboConfig(AppConfig):
    name = 'Financeiro'
