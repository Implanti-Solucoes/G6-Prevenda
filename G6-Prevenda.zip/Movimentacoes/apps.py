from django.apps import AppConfig


class PrevendaConfig(AppConfig):
    name = 'Movimentacoes'
